#ifndef CALCULATOR_H
#define CALCULATOR_H

// Function declarations for calculator operations
void add_numbers(int a, int b);
void subtract_numbers(int a, int b);
void multiply_numbers(int a, int b);
void divide_numbers(int a, int b);

#endif

